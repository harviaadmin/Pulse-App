class AdminUser < ApplicationRecord
end
